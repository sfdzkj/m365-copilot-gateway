# M365 Copilot → OpenAI Compatible Gateway（v1.0.6 完整版）

> **目标**：对外提供 **OpenAI 标准接口** `POST /v1/chat/completions`（支持 `stream=true`），并让调用方通过 **多个 `X-User-Key`** 自行切换授权用户。
>
> **内部**：使用 Microsoft Graph `/beta` 的 **Microsoft 365 Copilot Chat API**（支持 SSE 流式 `chatOverStream`）。citeturn4search32turn2search17turn2search29
>
> ✅ 本版本 **v1.0.6** = **完整流式 + 结构化日志** + **多 Key 管理（label/list/delete/rotate）**。

---

## 1. 关键特性

### 1.1 OpenAI 兼容接口

- `GET /v1/models`
- `POST /v1/chat/completions`
  - `stream=false`：一次性返回
  - `stream=true`：SSE 逐步输出（OpenAI chunk 格式）

### 1.2 多授权账户（调用方维护多个 `X-User-Key`）

- 设备码授权拿 key：
  - `POST /auth/device/start`（支持 `{"label":"xxx"}`）
  - `GET /auth/device/status/:txId`
- Key 管理（管理员）：
  - `GET /auth/keys`（列出所有 key，含 label、创建时间、脱敏展示）
  - `GET /auth/keys/:userKey`（查看 key 元数据）
  - `DELETE /auth/keys/:userKey`（删除/吊销 key）
  - `POST /auth/keys/:userKey/rotate`（轮换 key：生成新 key，旧 key 失效）
  - `POST /auth/keys/label`（修改 label）

### 1.3 可观测性（Docker logs 里可直接看）

- 结构化 JSON 日志输出到 stdout/stderr
- 每个请求自动生成/透传 `X-Request-Id`，全链路日志携带 `requestId`
- Graph 上游调用：记录 URL、HTTP 状态、耗时、Graph request-id
- SSE 流式：记录 stream start/end、事件块数量、JSON 解析失败数、最终字符数
- `/healthz`：检查 Redis 连通性与配置就绪状态
- `/debug/last-events`：查看最近上游 SSE 事件片段（管理员接口）

---

## 2. 前置条件（非常重要）

### 2.1 Copilot Chat API 的身份模型

Copilot Chat API 目前仅支持 **Delegated（委托）** 权限，不支持 Application（应用）权限，因此必须让每个“被切换的授权用户”自己完成一次登录授权后，才能用该用户身份调用。citeturn2search17turn2search29

### 2.2 Copilot Chat API 的许可

Copilot Chat API 的文档说明其许可要求与 Copilot add-on 相关；若出现 `It looks like you don’t have a valid license...`，基本是用户缺少对应许可。citeturn5search32turn13search61

---

## 3. Entra（Azure AD）应用注册（推荐按此配置）

### 3.1 注册应用

- 平台：**Web**
- Redirect URI（可添加多条）：
  - 本机/内网：`http://localhost:8080/auth/callback`
  - 公网 HTTPS：`https://你的域名/auth/callback`

> 本项目会根据 `.env` 的 `PUBLIC_BASE_URL` 生成回调：`{PUBLIC_BASE_URL}/auth/callback`

### 3.2 启用设备码（可选但推荐）

在 **Authentication** 页开启：
- **Allow public client flows** = Yes（device code 更稳）citeturn2search23

### 3.3 API 权限（Delegated）

按 Copilot Chat API 文档要求，为 Microsoft Graph 添加 **Delegated** 权限并 **Grant admin consent**：citeturn2search17turn2search29

- `Sites.Read.All`
- `Mail.Read`
- `People.Read.All`
- `OnlineMeetingTranscript.Read.All`
- `Chat.Read`
- `ChannelMessage.Read.All`
- `ExternalItem.Read.All`

---

## 4. 配置与启动（Docker Compose 一键启动）

### 4.1 配置 `.env`

```bash
cp .env.example .env
```

编辑 `.env`：
- `TENANT_ID / CLIENT_ID / CLIENT_SECRET`
- `PUBLIC_BASE_URL`
- `API_BEARER_TOKEN`
- `ADMIN_BEARER_TOKEN`（可选）
- `SESSION_SECRET`

### 4.2 启动

```bash
docker compose up -d --build
```

查看日志：

```bash
docker compose logs -f copilot-gw
```

健康检查：

```bash
curl http://localhost:8080/healthz
```

---

## 5. 典型使用流程（多授权账户）

### 5.1 新增授权账户（设备码）并打标签

```bash
curl -s http://localhost:8080/auth/device/start   -H 'Content-Type: application/json'   -d '{"label":"Alice-财务"}'
```

按返回的 `message` 打开 `verification_uri` 并输入 `user_code` 完成登录。

轮询：

```bash
curl -s http://localhost:8080/auth/device/status/<txId>
```

当 `status=complete`，得到 `user_key`。

### 5.2 列出所有 key（管理员）

```bash
curl -s http://localhost:8080/auth/keys   -H 'Authorization: Bearer <ADMIN或API_TOKEN>'
```

### 5.3 调用 OpenAI 标准接口（切换用户只需换 X-User-Key）

```bash
curl http://localhost:8080/v1/chat/completions   -H 'Authorization: Bearer <API_BEARER_TOKEN>'   -H 'X-User-Key: <user_key>'   -H 'Content-Type: application/json'   -d '{"model":"deep","stream":false,"messages":[{"role":"user","content":"写一个项目复盘模板"}]}'
```

---

## 6. 删除/轮换 key（管理员）

删除：

```bash
curl -s -X DELETE http://localhost:8080/auth/keys/<user_key>   -H 'Authorization: Bearer <ADMIN或API_TOKEN>'
```

轮换：

```bash
curl -s -X POST http://localhost:8080/auth/keys/<user_key>/rotate   -H 'Authorization: Bearer <ADMIN或API_TOKEN>'
```

---

## 7. 排障

### 7.1 查看最近上游事件（管理员）

```bash
curl -s http://localhost:8080/debug/last-events   -H 'Authorization: Bearer <ADMIN或API_TOKEN>'
```

---

## 8. 安全建议

- `CLIENT_SECRET` 一旦泄露，请立刻在 Entra 中吊销并生成新的。
- 建议设置 `ADMIN_BEARER_TOKEN` 与 `API_BEARER_TOKEN` 不同。
- `X-User-Key` 等同“用户会话密钥”，建议定期 rotate。
